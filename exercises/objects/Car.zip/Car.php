<?php 


class Car {

    private $marca;
    private $modelo;
    private $conduciendo;

        // constructor and destructor

    function __construct(){

        echo "Auto Fabricado  <br>";
    }

    function __destruct(){
        echo "Auto Destruido  <br>";
    }


    public function getMarca()
    {
        return $this->marca;
    }

    public function setMarca($marca){
        $this->marca = $marca;
    }
    
    public function getModelo()
    {
        return $this->modelo;
    }

    public function setModelo($modelo){
        $this->modelo = $modelo;
    }
    

    
    // functions


    public function conduciendo()
    {
        if ($this->conduciendo == true){
            echo "estas conduciendo  <br>";

        } else {
            $this->conduciendo = true;
            echo "Empezando a conducir  <br>";
        }
    
    }




}

?>